fx_version 'cerulean'

game 'gta5'

author 'mt scripts'

description 'mt-ammurobbery'

version '0.2'

shared_scripts {
    '@qb-core/shared/locale.lua',
    'locales/en.lua',
    'config/config.lua',
}

client_scripts{
    'client/client.lua',
    'client/targets.lua',
}

server_scripts{
    'server/server.lua',
}
